//------Home page---------
const salonImage = document.getElementById('salonImage');

salonImage.addEventListener('click', () => {
  if (salonImage.classList.contains('enlarged')) {
    salonImage.classList.remove('enlarged');
  } else {
    salonImage.classList.add('enlarged');
  }
});

//--------registration-------------------
const registrationForm = document.getElementById('registrationForm');

registrationForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;


  
// Validate the form data
  if (!validateUsername(username)) {
    alert('Invalid username');
    return;
  }

  if (!validateEmail(email)) {
    alert('Invalid email');
    return;
  }

  if (!validatePassword(password)) {
    alert('Invalid password');
    return;
  }

  // Submit the form data to the server
  // ...
});
function validateUsername(username) {
    const regex = /^[a-zA-Z0-9]+$/;
    return regex.test(username);
  }
  
  function validateEmail(email) {
    const regex = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
    return regex.test(email);
  }
  
  function validatePassword(password) {
    return password.length >= 6;
  }

  //-----------login----------------
  const loginForm = document.getElementById('loginForm');
const loginFormMessage = document.getElementById('loginFormMessage');

loginForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  // Validate the form data
  if (!validateUsername(username)) {
    loginFormMessage.textContent = 'Invalid username';
    loginFormMessage.style.color = 'red';
    return;
  }

  if (!validatePassword(password)) {
    loginFormMessage.textContent = 'Invalid password';
    loginFormMessage.style.color = 'red';
    return;
  }

  // Submit the form data to the server
  // ...
});

//---------contact------------------------

const contactForm = document.getElementById('contactForm');

contactForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const message = document.getElementById('message').value;

  // Validate the form data
  if (!validateName(name)) {
    alert('Invalid name');
    return;
  }

  if (!validateEmail(email)) {
    alert('Invalid email');
    return;
  }

  if (!validateMessage(message)) {
    alert('Invalid message');
    return;
  }

  // Submit the form data to the server
  // ...

  // Reset the form
  document.getElementById('contactForm').reset();
});

function validateName(name) {
  const regex = /^[a-zA-Z\s]+$/;
  return regex.test(name);
}

function validateEmail(email) {
  const regex = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
  return regex.test(email);
}

function validateMessage(message) {
  return message.length > 0;
}

//-------------------service---------------------------
// main.js

document.addEventListener("DOMContentLoaded", function () {
    // Sample data (you can replace this with data from my Spring Boot backend)
    const servicesData = [
        { service: "Haircut", price: 30 },
        { service: "Coloring", price: "Starting at $50" },
        { service: "Styling", price: "Starting at $25" },
        { service: "Treatments", price: "Starting at $35" },
        { service: "Extensions", price: "Starting at $100" },
    ];

    // Get the table body element
    const tableBody = document.querySelector("#services table tbody");

    // Function to populate the table with data
    function populateTable() {
        // Clear existing rows
        tableBody.innerHTML = "";

        // Loop through the data and create rows
        servicesData.forEach((service) => {
            const row = tableBody.insertRow();
            const cellService = row.insertCell(0);
            const cellPrice = row.insertCell(1);

            cellService.textContent = service.service;
            cellPrice.textContent = service.price;
        });
    }

    // Call the function to populate the table on page load
    populateTable();
});